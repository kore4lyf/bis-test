<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'B/K_*dt3K<Sb-rw%woO95H&T[y)DWE4t@Te:{h>9jh=lM(5]t{rtf1-4WX7W(=?&' );
define( 'SECURE_AUTH_KEY',   '3q dZ6<CcbSi]x,ijZQ.^=Bc+Su)Sp8,X@D&9,F%XaOHf}^-#X $|h7LQDPJmh#Q' );
define( 'LOGGED_IN_KEY',     'QwF4 Jp&/d)$_>Oc}C#]x%jhi]yHw*,^e8x.djA09h&TQaR==T#dVU&t -]&9P,k' );
define( 'NONCE_KEY',         '&nU!|lWazBy^[[M{DKs9.`QCFM+uFfxPHQdQq.7{(bJHP?xcQP9]Pk+Ew*6sEL>>' );
define( 'AUTH_SALT',         'ONLV/:&}AD|.q8pcr!|b-D=0U}HAR>VDz1RLA7vNIN33xzQ(/Y&ufz36D~r*:<lc' );
define( 'SECURE_AUTH_SALT',  'roPaY60MIo?i=OXuQHQ:;Ye29- A_Z)?<}GDU9zTt|a1x_#3e4C[Tkv_i0?5~Cus' );
define( 'LOGGED_IN_SALT',    '~DkDM~<J6?cTaZ[,h=l;o<tzSc_@^>p1U7wV{J)W4g9x6O:%1J~7`{&oP8BN4-+A' );
define( 'NONCE_SALT',        'Z<2[91$#ICl>vLxbhpz=8hBm$OXPyu/93bo1a[BS@bu3k]fGX}Y1I.9a=VRTEU#q' );
define( 'WP_CACHE_KEY_SALT', 'cHv,GMf%p5kQP{R%{g2%b,5(O,1=A,pQ13Jjom(xF8gwYt~ZF{Zn~g_1`$B%jlUU' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'WP_ENVIRONMENT_TYPE', 'local' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
